package ac1;

public class Encerrar {
    public static void main() {
        System.out.println("Até logo!");
        System.out.println("Feito por Adalberto Nascimento, 2ADSB, RA: 01212091");
    }
}

// Feito por Adalberto Nascimento, 2ADSB, RA: 01212091