package ProjetoIndividualJava;

public class Funcao6 {
    // Encerrar o programa
    public static void main() {
        System.out.println("Obrigado por usar nossos serviços!\n" +
                "Aproveite para me seguir no LinkedIn:\n" +
                "https://www.linkedin.com/in/adalberto-nascimento/ :)\n" +
                "\nMe esforcei para utilizar apenas o que está sendo ensinado nas aulas. Mas estou desenvolvendo um sistema em Kotlin,\n" +
                "caso desejar, enviarei o link do repositório no GitHub em seu email quando estiver finalizado :D");
    }
}
